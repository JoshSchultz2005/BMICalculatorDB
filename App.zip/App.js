import React, { useState, useEffect } from 'react';
import {
  Text,
  ScrollView,
  StyleSheet,
  SafeAreaView,
  Pressable,
  TextInput,
} from 'react-native';
import * as SQLite from 'expo-sqlite';
import * as SplashScreen from 'expo-splash-screen';

SplashScreen.preventAutoHideAsync();
setTimeout(SplashScreen.hideAsync, 2000);

const db = SQLite.openDatabase("bmiDB.db");


export default function App() {
var Weight = ''
var Height = ''
var BMI = 0
var Content = false
var Category = ''
var results = '';

  useEffect(() => {
    db.transaction((tx) => {
      tx.executeSql(
        "drop table items;"
      );
      tx.executeSql(
        "create table if not exists items (id integer primary key not null, itemDate real, bmi float, value text, );"
      );
    });
  }, []);

  function onSave() {
    BMI = ((Weight / (Height * Height))* 703).toFixed(1)
    Content = true;

    if (BMI <= 18.4){
      Category = 'Underweight';
    } 
    else if (BMI <= 24.9){
      Category = 'Healthy';
    }
    else if (BMI <= 29.9){
      Category = 'Overweight';
    }
    else { Category = 'Obese'; }

    results = "Body Mass Index is " + BMI + "\t(" + Category + ")";

    db.transaction(
      (tx) => {
        tx.executeSql("insert into items (itemDate, bmi, weight, height) values (julianday('now'), ?, ?, ?)", [BMI, Weight, Height]);
        tx.executeSql("select * from items", [], (_, { rows }) =>
          console.log(JSON.stringify(rows))
        );
      },
      null
    );
  };

  return (
    <SafeAreaView style={styles.main}>
      <Text style={styles.toolbar}>BMI Calculator</Text>
      <ScrollView style={styles.main}>
        <TextInput 
          style={styles.input} 
          placeholder={'Weight in Pounds'}
          onChangeText={(weight) => Weight = weight}
        >
        </TextInput>
        <TextInput 
          style={styles.input} 
          placeholder={'Height in Inches'}
          onChangeText={(height) => Height = height}
        >
        </TextInput>
        <Pressable style={styles.button} onPress={onSave}>
          <Text style={styles.buttonText}>
            Compute BMI
          </Text>
        </Pressable>
        <ScrollView style={styles.BMIInfoView}>
        {
          Content ? <Text style={styles.BMIInfo}>{results}</Text> : null
        }
        </ScrollView>
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  main: {
    flex: 1,
  },
  toolbar: {
    backgroundColor: '#f4511e',
    color: 'white',
    fontSize: 28,
    padding: 20,
    textAlign: 'center',
    fontWeight: 'bold',
    marginBottom: 5
  },
  input: {
    backgroundColor: '#f5f5f5',
    fontSize: 24,
    padding: 5,
    margin: 5
  },
  button: {
    backgroundColor: '#34495e',
    margin: 5,
  },
  buttonText: {
    color: 'white',
    fontSize: 24,
    padding: 10,
    textAlign: 'center',
  },
  BMIInfoView: {
    marginBottom: 75,
    marginTop: 75,
  },
  BMIInfo: {
    fontSize: 28,
    textAlign: 'center',
  },
  assessment: {
    fontSize: 20,
  }
});
